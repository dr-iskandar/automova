"use client";

import Home from "../page";

export default function LoginPage() {
  return <Home forceLoginScreen />;
}
